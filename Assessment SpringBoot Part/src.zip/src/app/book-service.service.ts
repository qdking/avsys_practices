import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class BookServiceService {

  constructor(private http_name: HttpClient) { }

  private baseUrL = "http://localhost:8080/library";

  // Check method parameters, and Observ.generics same as the one declared in eclipse backend
  listAllBooks(): Observable<any>
  {
    return this.http_name.get(`${this.baseUrL}/book`);  
    //return this.http_name.get("http://localhost:8080/library/book");
  }

  // generics Object because it won't know for sure if it's book
  insertBook(book: Book): Observable<Object>
  {
    return this.http_name.post(`${this.baseUrL}/insertBook`, book);  
  }

  getBookById(book_id: number): Observable<Book>
  {
    return this.http_name.get<Book>(`${this.baseUrL}/book/${book_id}`);  
  }

  updateBook(book_id: number, book: Book): Observable<Object>{
    return this.http_name.put(`${this.baseUrL}/updateBook/${book_id}`, book);
  }

  deleteBook(book_id: number): Observable<Object>
  {
    return this.http_name.delete(`${this.baseUrL}/deleteBook/${book_id}`);
  }
}
