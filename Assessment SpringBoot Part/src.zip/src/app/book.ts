export class Book
{
    book_id!: number;
    book_title!: string;
    book_author!: string;
    book_publisher!: string;
    book_date!: Date;
}