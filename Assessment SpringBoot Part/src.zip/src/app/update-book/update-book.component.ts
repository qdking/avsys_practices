import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Book } from '../book';
import { BookServiceService } from '../book-service.service';

@Component({
  selector: 'app-update-book',
  templateUrl: './update-book.component.html',
  styleUrls: ['./update-book.component.css']
})
export class UpdateBookComponent implements OnInit {
  book_id!: number;
  book: Book = new Book();

  constructor(private service: BookServiceService, 
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    // Get book_id from the HTTP click in previous list
    this.book_id = this.route.snapshot.params['book_id'];

    // Subscribe the id if it is working
    this.service.getBookById(this.book_id).subscribe(data => {
      this.book = data;
    }, error => console.log(error));
  }

  onSubmitMethod()
  {
    this.service.updateBook(this.book_id, this.book).subscribe(data =>
      this.goBackToBookList()
      , error => console.log(error));
  }
  
  goBackToBookList()
  {
    this.router.navigate(['/book']);
  }

}
