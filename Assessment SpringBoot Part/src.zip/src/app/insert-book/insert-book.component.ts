import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from '../book';
import { BookServiceService } from '../book-service.service';

@Component({
  selector: 'app-insert-book',
  templateUrl: './insert-book.component.html',
  styleUrls: ['./insert-book.component.css']
})
export class InsertBookComponent implements OnInit {
  book: Book = new Book();
  
  constructor(
      private service: BookServiceService,
      private router: Router) { }

  ngOnInit(): void {
    console.log("TS file is working.");
  }

  // Creating new book object to accept values from the Form
  

  insertBook()
  {
    // parse new book object into the service insert method
    this.service.insertBook(this.book).subscribe(data => 
      {
        console.log("Insert book is successful.");
        console.log(data);
        // navigate back to list of books
        this.goBackToListOfBooks();
      
      }, error => console.log(error));
  }

  goBackToListOfBooks()
  {
    // called route in constructor parameters
    this.router.navigate(['/book']);
  }

  onSubmitMethod()
  {
    console.log("Submit button is getting clicked.")
    console.log(this.book);
    // Upon hitting submit button, call the Insert Method
    this.insertBook();
  }

}
