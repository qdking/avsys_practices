import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Book } from '../book';
import { BookServiceService } from '../book-service.service';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {

  // books!: Observable<Book[]>;
  //books!: Observable<Book[]>;
  books!: Book[];

  constructor(private service: BookServiceService,
    private router: Router) { }

  ngOnInit(): void {
    this.listAllBooks();
  }

  listAllBooks()
  {
    this.service.listAllBooks().subscribe(data => 
      {this.books = data;});
  }

  // Delete Book Entry
  deleteBook(book_id: number)
  {
    this.service.deleteBook(book_id).subscribe(data =>
      {
        console.log(data);
        console.log("Delete successful");
        // Call the list all books method to see the changes
        this.listAllBooks();
      })
  }

  // Send book_id parameter into Update Book Compononent and ReRoute/redirect it to the updateBook path.
  updateBook(book_id: number)
  {
    this.router.navigate(['updateBook', book_id]);
  }


  // Code Dump

  // goBackToListOfBooks()
  // {
  //   // called route in constructor parameters
  //   this.router.navigate(['book']);
  // }

  // books = [
    
  //     {
  //       "book_id": 1,
  //       "book_title": "Book Title Name",
  //       "book_author": "Mr Smith",
  //       "book_publisher": "Publisher Name",
  //       "book_date": ""
  //     }
    
  // ];

}
